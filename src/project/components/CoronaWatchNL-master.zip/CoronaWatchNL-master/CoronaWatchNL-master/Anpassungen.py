from pathlib import Path
import re
import datetime

import pandas as pd
from pandas import DataFrame
import numpy

df = pd.read_csv(Path("data", "rivm_corona_in_nl.csv"))

df2 = pd.read_csv(Path("data", "rivm_corona_in_nl_fatalities.csv"))

df2["Gemeentenaam"] = "Netherlands"
df2["Gemeentecode"] = "9999"
df2["Provincienaam"] = "fatalities"

df2 = pd.DataFrame(df2, columns = ["Datum", "Gemeentenaam", "Gemeentecode", "Provincienaam", "Aantal"])

df2["Aantal"] = df2["Aantal"] * -1

df3 = pd.read_csv(Path("data", "rivm_corona_in_nl_hosp.csv"))

df3["Gemeentenaam"] = "Netherlands"
df3["Gemeentecode"] = "9998"
df3["Provincienaam"] = "hospital"

df3 = pd.DataFrame(df3, columns = ["Datum", "Gemeentenaam", "Gemeentecode", "Provincienaam", "Aantal"])

df3.to_csv(Path("data", "rivm_corona_in_nl_hosp_update.csv"), index = False)
