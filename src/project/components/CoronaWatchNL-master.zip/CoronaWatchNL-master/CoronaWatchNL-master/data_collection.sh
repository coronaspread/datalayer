python download_rivm_corona.py
python merge_data.py
python render_datasets.py