python plot_scripts/animated_maps.py
python plot_scripts/python_plots.py
Rscript plot_scripts/plots.R